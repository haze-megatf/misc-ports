Assembled from various open sources
Rename desired skin to v_bat_0.tga